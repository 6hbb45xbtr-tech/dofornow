
CJ URL UI (drop-in)

Put `index.html` into your existing frontend (e.g., `/frontend/add.html`) and deploy. 
Set your backend API once. Then you can rip ONE URL or a pasted BATCH list, and view Recent with inline players.
